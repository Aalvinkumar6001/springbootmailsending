package com.cts.MailLinkRegisteration.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.MailLinkRegisteration.model.Register;


public interface RegisterRepository extends JpaRepository<Register, Long> {
	  
}