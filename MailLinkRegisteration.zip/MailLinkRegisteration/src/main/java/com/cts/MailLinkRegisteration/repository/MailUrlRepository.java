package com.cts.MailLinkRegisteration.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.MailLinkRegisteration.model.MailUrl;


public interface MailUrlRepository extends JpaRepository<MailUrl, Long> {
	  @Query(value = "SELECT * FROM mail_url WHERE random_string = ?1", nativeQuery = true)
	  MailUrl findByRandomString(String random_string); 
	  
	  @Query(value = "SELECT * FROM mail_url", nativeQuery = true)
	  List<MailUrl> updateUrlExpNull();

}
