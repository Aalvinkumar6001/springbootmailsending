/*package com.cts.MailLinkRegisteration.scheduler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.cts.MailLinkRegisteration.model.MailUrl;
import com.cts.MailLinkRegisteration.repository.MailUrlRepository;

@Component
@EnableScheduling
public class Scheduler {

	@Autowired
	private static MailUrlRepository mailurldata;
	
    @Scheduled(fixedDelay =40000)
    public static void demoServiceMethod() throws ParseException
    {
    	
		List<MailUrl> urlNull = mailurldata.updateUrlExpNull();
		long timeInMillis = System.currentTimeMillis();
		Calendar cal1 = Calendar.getInstance();
		cal1.setTimeInMillis(timeInMillis);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
		String newDate = dateFormat.format(cal1.getTime()); 
		Date currentData =dateFormat.parse(newDate);
		for(MailUrl d: urlNull)
		if(d.getExpieryDate().before(currentData)) {
	        MailUrl m = new MailUrl();
	        m.setId(d.getId());
	        m.setEmployee(d.getEmployee());
	        m.setRandomString(null);
	        m.setExpieryDate(null);
	        m.setRegister(d.getRegister());
	        mailurldata.save(m);
		}

    }
}*/