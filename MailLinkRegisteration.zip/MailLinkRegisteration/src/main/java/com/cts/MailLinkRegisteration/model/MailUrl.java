package com.cts.MailLinkRegisteration.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class MailUrl{
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private long id;
	private Date expieryDate ;
	private String randomString;

	@OneToOne
	private Employee employee;
	
	@OneToOne
	private Register register;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Date getExpieryDate() {
		return expieryDate;
	}
	public void setExpieryDate(Date expieryDate) {
		this.expieryDate = expieryDate;
	}
	public String getRandomString() {
		return randomString;
	}
	public void setRandomString(String randomString) {
		this.randomString = randomString;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public Register getRegister() {
		return register;
	}
	public void setRegister(Register register) {
		this.register = register;
	}

	
	
}
