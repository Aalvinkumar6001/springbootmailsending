package com.cts.MailLinkRegisteration.service;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.cts.MailLinkRegisteration.model.Mail;


@Service
public class EmployeeService {
	    @Autowired
	    private JavaMailSender sender;
	 
		@Autowired
		private TemplateEngine templateEngine;
	
	
	public String randomUrl() {
		UUID uuid = UUID.randomUUID();
		String randomUUIDString = uuid.toString();
		return randomUUIDString;
	}
	public Date expiryDate() throws ParseException {
		long timeInMillis = System.currentTimeMillis();
		Calendar cal1 = Calendar.getInstance();
		cal1.setTimeInMillis(timeInMillis);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
		   
		//Number of Days to add
		cal1.add(Calendar.DAY_OF_MONTH, 1);  
		//Date after adding the days to the current date
		String newDate = dateFormat.format(cal1.getTime()); 
		Date dateExp =dateFormat.parse(newDate);
		return dateExp;
	}
	
	public void sendSimpleMessage(Mail mail) throws MessagingException {
		 MimeMessage message = sender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
    
       Context context = new Context();
       context.setVariables(mail.getModel());
       String html = templateEngine.process("email-template", context);

       helper.setTo(mail.getTo());
       helper.setText(html, true);
       helper.setSubject(mail.getSubject());
       helper.setFrom(mail.getFrom());
       
       sender.send(message);
   }

}
