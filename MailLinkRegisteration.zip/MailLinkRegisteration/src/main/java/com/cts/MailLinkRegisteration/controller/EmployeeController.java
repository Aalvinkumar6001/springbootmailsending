package com.cts.MailLinkRegisteration.controller;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.MailLinkRegisteration.model.Employee;
import com.cts.MailLinkRegisteration.model.Mail;
import com.cts.MailLinkRegisteration.model.MailUrl;
import com.cts.MailLinkRegisteration.model.Register;
import com.cts.MailLinkRegisteration.repository.EmployeeRepository;
import com.cts.MailLinkRegisteration.repository.MailUrlRepository;
import com.cts.MailLinkRegisteration.repository.RegisterRepository;
import com.cts.MailLinkRegisteration.service.EmployeeService;




@Controller
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeData;
	

	@Autowired
	private MailUrlRepository mailurldata;
	
	@Autowired
	private EmployeeService employeeservice;
	
	@Autowired
	private RegisterRepository registerData;
	
	 String urlLink;

	@RequestMapping(value = "/submittedEmployee", method = RequestMethod.POST)
	public ModelAndView newEmployee(@ModelAttribute Employee employee, BindingResult bindResult) throws ParseException, MessagingException {
		ModelAndView modelAndView = new ModelAndView();
		Employee employeeExists = employeeData.findByEmailAddress(employee.getEmail());
		if (employeeExists != null) {
			bindResult.rejectValue("email", "error.user",
					"There is already a user registered with the email provided");
		}
		if (bindResult.hasErrors()) {
			modelAndView.setViewName("newEmployee");
		} else {
		modelAndView.setViewName("allEmployees");
		//saving employee data into database
		employeeData.save(employee);
		// saving urlexpdate and randomstring in database
		
		MailUrl mailurl = new MailUrl();
		mailurl.setRandomString(employeeservice.randomUrl());
		mailurl.setExpieryDate(employeeservice.expiryDate());
		mailurl.setEmployee(employee);
		mailurldata.save(mailurl);
		//sending link through mail
		 Mail mail = new Mail();
	        mail.setFrom("aalvinkumar6001@gmail.com");
	        mail.setTo("aalvinkumar6001@gmail.com");
	        mail.setSubject("Sending Email with Thymeleaf form aalvin");
	        mail.setActivationLink(mailurl.getRandomString());
	        Map model = new HashMap();
	        model.put("name", "cognizant.com");
	        model.put("location", "bengaluru");
	        model.put("signature", "all is well");
	        model.put("mailurl", mail.getActivationLink());
	        mail.setModel(model);
	        employeeservice.sendSimpleMessage(mail);
		}
		return modelAndView;

	}

	@RequestMapping(value = "/addNewEmployee", method = RequestMethod.GET)
	public ModelAndView addNewEmployee() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("newEmployee");
		return modelAndView;

	}
	@RequestMapping(value = "/registers/{randomString}", method = RequestMethod.GET)
	public ModelAndView register() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("registers");
		return modelAndView;
	}
	
	@RequestMapping(value = "/registers/{randomString}", method = RequestMethod.POST)
	public ModelAndView register(@PathVariable("randomString") String randomString,@ModelAttribute Register register, BindingResult bindResult ) {
		ModelAndView modelAndView = new ModelAndView();
		System.out.println("d0254b19-2ddb-4304-a314-c542ce311097");
		MailUrl mailUrlExsist = mailurldata.findByRandomString("d6ca00ad-2459-4589-a439-014692a7710a");
		System.out.println(mailUrlExsist);

      if(mailUrlExsist == null) {
			bindResult.rejectValue("email is sended", "error.MailUrl",
					"There is already a expired registered link the email provided");
		}
		if (bindResult.hasErrors()) {
			modelAndView.setViewName("newEmployee");
		} else {
        registerData.save(register);
        MailUrl m = new MailUrl();
        System.out.println(randomString);
        m.setId(mailUrlExsist.getId());
        m.setEmployee(mailUrlExsist.getEmployee());
        m.setRandomString(mailUrlExsist.getRandomString());
        m.setExpieryDate(mailUrlExsist.getExpieryDate());
        m.setRegister(register);
        mailurldata.save(m);
		modelAndView.setViewName("submitregister");
		}
		return modelAndView;
	
	}
   

}
